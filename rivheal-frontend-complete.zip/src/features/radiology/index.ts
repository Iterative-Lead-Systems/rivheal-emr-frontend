export { RadiologyPage } from './RadiologyPage';
