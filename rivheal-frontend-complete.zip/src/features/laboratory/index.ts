export { LaboratoryPage } from './LaboratoryPage';
