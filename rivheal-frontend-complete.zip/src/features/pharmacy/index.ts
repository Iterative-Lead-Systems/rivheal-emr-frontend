export { PharmacyPage } from './PharmacyPage';
