export { DepartmentsPage } from './DepartmentsPage';
