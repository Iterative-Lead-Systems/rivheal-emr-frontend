export { PatientListPage } from './PatientListPage';
export { PatientRegistrationPage } from './PatientRegistrationPage';
export { PatientDetailPage } from './PatientDetailPage';
