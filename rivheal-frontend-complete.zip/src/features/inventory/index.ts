export { InventoryPage } from './InventoryPage';
