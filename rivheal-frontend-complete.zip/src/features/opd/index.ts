export { ConsultationPage } from './ConsultationPage';
export { OPDQueuePage } from './OPDQueuePage';

