export { WardManagementPage } from './WardManagementPage';
